import pandas as pd

df = pd.read_csv("clean_dataset.csv")
print("Rows:", len(df))
print("Total sales:", round(df["Sales"].sum(), 2))
print("Average sales:", round(df["Sales"].mean(), 2))
print("Average rating:", round(df["Rating"].mean(), 2))
print("\nSales by outlet type:")
print(df.groupby("Outlet Type")["Sales"].sum().sort_values(ascending=False))
print("\nSales by item type:")
print(df.groupby("Item Type")["Sales"].sum().sort_values(ascending=False))
