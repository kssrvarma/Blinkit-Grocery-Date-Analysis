import pandas as pd

INPUT_FILE = "Dataset.xlsx"
OUTPUT_FILE = "clean_dataset.csv"

df = pd.read_excel(INPUT_FILE)
df["Item Fat Content"] = df["Item Fat Content"].replace({
    "LF": "Low Fat", "low fat": "Low Fat", "reg": "Regular", "regular": "Regular"
})
for col in ["Item Weight", "Item Visibility"]:
    df[col] = df[col].fillna(df[col].median())
df.to_csv(OUTPUT_FILE, index=False)
print(f"Saved cleaned data to {OUTPUT_FILE}; rows={len(df)}")
