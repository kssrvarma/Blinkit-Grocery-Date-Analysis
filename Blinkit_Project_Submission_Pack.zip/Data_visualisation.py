import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("clean_dataset.csv")
sales_by_type = df.groupby("Item Type")["Sales"].sum().sort_values(ascending=False)
sales_by_outlet = df.groupby("Outlet Type")["Sales"].sum().sort_values(ascending=False)

sales_by_type.plot(kind="bar", figsize=(12, 5), title="Sales by Item Type")
plt.ylabel("Sales")
plt.tight_layout()
plt.savefig("sales_by_item_type.png", dpi=160)
plt.close()

sales_by_outlet.plot(kind="bar", figsize=(9, 5), title="Sales by Outlet Type")
plt.ylabel("Sales")
plt.tight_layout()
plt.savefig("sales_by_outlet_type.png", dpi=160)
plt.close()
