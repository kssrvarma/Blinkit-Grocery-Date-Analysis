# Blinkit Grocery Sales Analysis Using Power BI

## Team
- K Raghavendra Varma — 2603A53L01
- M Shiva Krishna — 2503A52029
- M Sai Charan — 2503A51291

## Included files
- `Dataset.xlsx` — supplied source dataset
- `clean_dataset.csv` / `clean_dataset.xlsx` — cleaned dataset
- `data_cleaning.py` — data cleaning script
- `Data_analysis.py` — summary analysis script
- `Data_visualisation.py` — chart generation script
- `Project_Proposal.txt` — project proposal
- `Project_Report.pdf` — final report
- `Project_Presentation.pptx` — presentation
- `dashboard_reference.jpg` — screenshot reference of the Power BI dashboard

## Dataset summary
- Records: 8,523
- Columns: 12
- Total sales: 1,201,681.49
- Average sales: 140.99
- Average rating: 3.97

## Important: Power BI file
The `.pbix` file is not included because it must be saved/exported from Power BI Desktop by the team. Open your Power BI report and use **File > Save As** to save `Dashboard.pbix`, then add it to this folder before final upload.

## Run the Python scripts
Install dependencies with:
`pip install pandas openpyxl matplotlib`

Run in order:
1. `python data_cleaning.py`
2. `python Data_analysis.py`
3. `python Data_visualisation.py`

## GitHub
Create a **Public** repository and upload this folder. Do not upload private credentials or personal information.
